/*
 * Copyright (C) 2010-2011 Richard Hughes <richard@hughsie.com>
 *
 * SPDX-License-Identifier: LGPL-2.1+
 */

#pragma once

#include <glib.h>

G_BEGIN_DECLS

GOptionGroup	*fu_debug_get_option_group	(void);

G_END_DECLS
