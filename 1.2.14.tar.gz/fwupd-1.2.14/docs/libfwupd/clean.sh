rm -f *.txt
rm -rf html/
rm -rf xml/
rm -rf tmpl/
rm -f *.stamp
