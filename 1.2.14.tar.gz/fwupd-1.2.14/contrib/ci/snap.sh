#!/bin/sh

cd /build
snapcraft
