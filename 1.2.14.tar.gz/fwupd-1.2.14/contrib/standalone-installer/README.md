# Standalone installer

This is a script that will build a standalone installer around the fwupd snap or flatpak.
This can be used for distributing updates that use fwupd on machines without networking and the needed tools.

For usage instructions, view:
```
./make.py --help
```
