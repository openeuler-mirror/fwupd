#/bin/sh
echo "this is a test"
sleep 1
echo "this is another line1"
echo "this is another line2"
echo "this is another line3"
echo "this is another line4"
sleep 1
echo "done!"
exit 0
