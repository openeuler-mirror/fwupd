#/bin/sh
cat source.bin | rev > firmware.bin
