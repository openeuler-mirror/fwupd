Test Support
============

Introduction
------------

This plugin is used when running the self tests in the fwupd project.

GUID Generation
---------------

The devices created by this plugin use hardcoded GUIDs that do not correspond
to any kind of DeviceInstanceId values.
