rm *.rom
wget http://www.techpowerup.com/vgabios/375/Asus.9800PRO.256.unknown.031114.rom
wget http://www.techpowerup.com/vgabios/133037/Asus.HD7970.3072.121018.rom
wget http://www.techpowerup.com/vgabios/148214/Asus.R9290X.4096.131014.rom
wget http://www.techpowerup.com/vgabios/74257/Asus.GTX480.1536.100406_1.rom
wget http://www.techpowerup.com/vgabios/162406/Asus.GTX980.4096.140905.rom
wget http://www.techpowerup.com/vgabios/157835/Asus.TitanBlack.6144.140212.rom
