UPower Support
==============

Introduction
------------

This plugin is used to ensure that some updates are not done on battery power.
