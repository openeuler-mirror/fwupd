/*
 * Copyright (C) 2022 Richard Hughes <richard@hughsie.com>
 *
 * SPDX-License-Identifier: LGPL-2.1+
 */

#pragma once

#include <fwupdplugin.h>

G_DECLARE_FINAL_TYPE(FuAndroidBootPlugin, fu_android_boot_plugin, FU, ANDROID_BOOT_PLUGIN, FuPlugin)
