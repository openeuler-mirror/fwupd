# ACPI FACP

## Introduction

This plugin checks if S2I sleep is available. The result will be stored in an
security attribute for HSI.

## External Interface Access

This plugin requires read access to `/sys/firmware/acpi/tables`.
