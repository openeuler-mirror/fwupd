---
name: Question
about: Ask a question about the project or how to do something
title: ''
labels: question
assignees: ''

---

**Describe the question**
A clear and concise description of what you are wondering about.

**fwupd version information**
Please provide the version of the daemon and client if applicable to your current installation of `fwupd`.

```shell
fwupdmgr --version
```
